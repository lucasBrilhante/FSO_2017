#ifndef _SENO_
#define _SENO_
  void seno(double);
#endif